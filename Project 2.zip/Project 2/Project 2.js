angular.module('App', []);

function Ctrl($scope) {
$scope.input={number : '0'};
  $scope.friends =
      [];
  $scope.predicate = '';
  angular.forEach($scope.friends, function (friend) {
  friend.number = parseFloat(friend.number);
});
  var numbers = new RegExp(/^[0-9]+$/);
$scope.addNumbers = function(inputvalue){
	if(numbers.test(inputvalue.number) ){
$scope.friends.push(inputvalue);	
$scope.input={number : null};}
else{
	alert("please enter numbers only");
}
}
$scope.remove = function(index){
  $scope.friends.splice(index);
};

$scope.sorting=function(){
$scope.predicate = '-number';
angular.forEach($scope.friends, function (friend) {
  friend.number = parseFloat(friend.number);
});
}
$scope.sorting1=function(){
$scope.predicate = '+number';
angular.forEach($scope.friends, function (friend) {
  friend.number = parseFloat(friend.number);
});
}
}