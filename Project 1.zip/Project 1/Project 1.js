angular.module('Demo', [])
  .controller('Demo', function($scope) {
    $scope.data = [
      { text: "The function and use of content management systems is to store and organize files, and provide version-controlled access to their data. CMS features vary widely. Simple systems showcase a handful of features, while other releases, notably enterprise systems, offer more complex and powerful functions. Most CMS include Web-based publishing, format management, revision control , indexing, search, and retrieval. The CMS increments the version number when new updates are added to an already-existing file. A CMS may serve as a central repository containing documents, movies, pictures, phone numbers, scientific data. <br> <br> CMSs can be used for storing, controlling, revising, semantically enriching and publishing documentation.Customer relationship management CRM is a system for managing a company’s interactions with current and future customers. It involves using technology to organize, automate and synchronize sales, marketing, customer service, and technical support.CRM systems track and measure marketing campaigns over multiple networks. These systems can track customer analysis by customer clicks and sales. Places where CRM is used include call centers, heavily utilized in social media, direct mail, data storage files, banks, and customer data queries." }
  
    ]

  })
  .filter('highlight', function($sce) {
    return function(text, phrase) {
      if (phrase) text = text.replace(new RegExp('('+phrase+')', 'gi'),
        '<span class="highlighted">$1</span>')

      return $sce.trustAsHtml(text)
    }
  })
